A Pen created at CodePen.io. You can find this one at https://codepen.io/ainalem/pen/LJYRxz.

 A set of hamburger menu open/close animations